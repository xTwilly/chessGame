#include "Piece.h"
//#include "MoveRules.h"
//#include "../Common.h"
#ifndef QUEEN
#define QUEEN
class Queen : public Piece {
public:
    Queen(int color = -1);
    ~Queen() {}

    void displayDetails() const override {
        cout << "Queen Details:" << endl;
        Piece::displayDetails();
    }
};

Queen::Queen(int color) {
    setColor(color);
    setPointValue(9);
    setMoveState(false);
    setPieceName("Q");
    setWhiteChar("♕");
    setBlackChar("♛");
    setMoveRules(*(new MoveRules(vector<int> {-1, 1, 0, 0, -1, 1, -1, 1, -2, 2, 0, 0, -2, 2, -2, 2, -3, 3, 0, 0, -3, 3, -3, 3, -4, 4, 0, 0, -4, 4, -4, 4, -5, 5, 0, 0, -5, 5, -5, 5, -6, 6, 0, 0, -6, 6, -6, 6, -7, 7, 0, 0, -7, 7, -7, 7}, vector<int> { 0, 0, -1, 1, -1, -1, 1, 1, 0, 0, -2, 2, -2, -2, 2, 2, 0, 0, -3, 3, -3, -3, 3, 3, 0, 0, -4, 4, -4, -4, 4, 4, 0, 0, -5, 5, -5, -5, 5, 5, 0, 0, -6, 6, -6, -6, 6, 6, 0, 0, -7, 7, -7, -7, 7, 7})));
}

#endif