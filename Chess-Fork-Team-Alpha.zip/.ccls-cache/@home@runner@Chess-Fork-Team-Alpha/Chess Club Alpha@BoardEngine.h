#include <direct.h>
#include "../Common.h"
#include "Piece.h"
#include "Pawn.h"
#include "Knight.h"
#ifndef BOARDENGINE
#define BOARDENGINE
//#include "PieceClass_ClubAlphaChess.cpp"

//class Piece {public: Piece(int color){}; Piece(){}};
class Rook   : public Piece {public: Rook(int color)   : Piece(color){}};
class Bishop : public Piece {public: Bishop(int color) : Piece(color){}};
class Queen  : public Piece {public: Queen(int color)  : Piece(color){}};
class King   : public Piece {public: King(int color)   : Piece(color){}};

class BoardEngine {
    private:
        vector<map<string, Piece>> BOARD;
        array<array<string, 8> , 8> board;
        enum pieceColor {WHITE, BLACK};
    protected:
        void startNewGame();
        void resetBoard();
        string createFiles(string filename);
        bool movePiece(string startLoc, string endLoc);
        bool validateMove(Piece movedPiece, string startLoc, string endLoc);
    public:
        //Constructors
        BoardEngine(string filename = "");
        ~BoardEngine() {}

        //Accessors
        vector<map<string, Piece>> getBoard() {return BOARD;}
        array<array<string, 8>, 8> getBoardInternal() {return board;}

        //Mutators

        //Functions
        void printBoardText();

};

BoardEngine::BoardEngine(string filename) {
    startNewGame();
    filename = createFiles(filename);
    bool genValid = false;

    while (!genValid) {
        //Temp loop-breaker
        genValid = true;
        
            
        ofstream moveWriter;
        moveWriter.open("games/" + filename, ofstream::app);
        if (!moveWriter.is_open()) {throw runtime_error("Cannot find " + filename);}
        ifstream moveReader;
        moveReader.open("games/" + filename);
        if (!moveReader.is_open()) {throw runtime_error("Cannot find " + filename);}

        string moveInfo;
        //Reads all moves from file
        while (getline(moveReader, moveInfo, ' ')) {
            movePiece(substring(moveInfo, 1, moveInfo.find(":")), substring(moveInfo, moveInfo.find(":") + 1));
        } 



        moveReader.close();
        moveWriter.close();
    }
}

void BoardEngine::startNewGame() {
    resetBoard();
    printBoardText();
}

string BoardEngine::createFiles(string filename) {
    //Creates new game file if not valid/provided
    ofstream fileCreator;
    if (!(filename.find("gameInstance") == 0 && isNum(filename.substr(string("gameInstance").length(), filename.length() - string("gameInstance.txt").length())))) {
        //Gets new game instance
        ifstream gameReader;
        gameReader.open("games/gameIndex.txt");
            //Create new gameIndex if not found
            if (!gameReader.is_open()) {
                fileCreator.open("games/gameIndex.txt");
                fileCreator << "0";
                fileCreator.close();
                gameReader.open("games/gameIndex.txt");
                if (!gameReader.is_open()) {throw runtime_error("Cannot find gameIndex.txt");}
            }
            getline(gameReader, filename);
        gameReader.close();

        //Updates gameInstance.txt
        ofstream gameWriter;
        gameWriter.open("games/gameIndex.txt");
            if (!gameWriter.is_open()) {throw runtime_error("Cannot find gameIndex.txt");}
            gameWriter << to_string(stoi(filename) + 1);
        gameWriter.close();

        //Creates new save file
        filename = "gameInstance" + to_string(stoi(filename) + 1) + ".txt";
        fileCreator.open("games/" + filename);
        if (!fileCreator.is_open()) {throw runtime_error("Cannot find " + filename);}
        fileCreator.close();
    }

    //TODO: Add check for file contents
    //Replaces file system explanation with new version
    fileCreator.open("games/MoveNotation.txt");
    if (!fileCreator.is_open()) {throw runtime_error("Cannot find " + filename);}
    fileCreator << "Every game is stored in an individual file." << endl;
    fileCreator << "Every move is stored on an individual row." << endl;
    fileCreator << "White's move is at the beginning of the row." << endl;
    fileCreator << "Black's move is at the end of the row." << endl;
    fileCreator << "Moves follow the following syntax:" << endl;
    fileCreator << "[Piece][Starting Location]:[Ending Location]." << endl;
    fileCreator << "Where [Piece] is the following abbreviations:" << endl;
    fileCreator << "{\n\tP = Pawn\n\tR = Rook\n\tN = Knight\n\tB = Bishop\n\tQ = Queen\n\tK = King\n}" << endl;
    fileCreator << "And Starting Location uses the Algebraic Notation" << endl;
    fileCreator << "And Ending Location uses the Algebraic Notation, " << endl;
    fileCreator << "With columns labeled on a grid between A-H" << endl;
    fileCreator << "And rows labeled on a grid between 1-8" << endl;
    fileCreator.close();

    //Creates file if not in directory
    fileCreator.open("games/" + filename, ofstream::app);
    if (!fileCreator.is_open()) {throw runtime_error("Cannot find " + filename);}
    fileCreator.close();

    return filename;
}

void BoardEngine::resetBoard() {
    map<string, Piece> tempMap;
    char letterList[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'};
    for (int i = 0; i < 8; ++i) {
        for (int j = 0; j < 8; ++j) {
            board[i][j] = to_string((i % 2 == j % 2)? WHITE : BLACK) + letterList[j] + to_string(8-i);
        }
        switch (i) {
            case 0: {
                tempMap[board[i][0]] = Rook(BLACK);
                tempMap[board[i][1]] = Knight(BLACK);
                tempMap[board[i][2]] = Bishop(BLACK);
                tempMap[board[i][3]] = Queen(BLACK);
                tempMap[board[i][4]] = King(BLACK);
                tempMap[board[i][5]] = Bishop(BLACK);
                tempMap[board[i][6]] = Knight(BLACK);
                tempMap[board[i][7]] = Rook(BLACK);
                break;
            }
            case 1: {
                tempMap[board[i][0]] = Pawn(BLACK);
                tempMap[board[i][1]] = Pawn(BLACK);
                tempMap[board[i][2]] = Pawn(BLACK);
                tempMap[board[i][3]] = Pawn(BLACK);
                tempMap[board[i][4]] = Pawn(BLACK);
                tempMap[board[i][5]] = Pawn(BLACK);
                tempMap[board[i][6]] = Pawn(BLACK);
                tempMap[board[i][7]] = Pawn(BLACK);
                break;
            }
            case 2:
            case 3:
            case 4:
            case 5: {
                tempMap[board[i][0]] = Piece(-1);
                tempMap[board[i][1]] = Piece(-1);
                tempMap[board[i][2]] = Piece(-1);
                tempMap[board[i][3]] = Piece(-1);
                tempMap[board[i][4]] = Piece(-1);
                tempMap[board[i][5]] = Piece(-1);
                tempMap[board[i][6]] = Piece(-1);
                tempMap[board[i][7]] = Piece(-1);
                break;
            }
            case 6: {
                tempMap[board[i][0]] = Pawn(WHITE);
                tempMap[board[i][1]] = Pawn(WHITE);
                tempMap[board[i][2]] = Pawn(WHITE);
                tempMap[board[i][3]] = Pawn(WHITE);
                tempMap[board[i][4]] = Pawn(WHITE);
                tempMap[board[i][5]] = Pawn(WHITE);
                tempMap[board[i][6]] = Pawn(WHITE);
                tempMap[board[i][7]] = Pawn(WHITE);
                break;
            }
            case 7: {
                tempMap[board[i][0]] = Rook(WHITE);
                tempMap[board[i][1]] = Knight(WHITE);
                tempMap[board[i][2]] = Bishop(WHITE);
                tempMap[board[i][3]] = Queen(WHITE);
                tempMap[board[i][4]] = King(WHITE);
                tempMap[board[i][5]] = Bishop(WHITE);
                tempMap[board[i][6]] = Knight(WHITE);
                tempMap[board[i][7]] = Rook(WHITE);
                break;
            }
            default: {
                break;
            }
        }
        BOARD.push_back(tempMap);
    }
}

bool BoardEngine::movePiece(string startLoc, string endLoc) {
    if (validateMove(BOARD.at(8 - stoi(startLoc.substr(1, 2)))[BOARD.at(8 - stoi(startLoc.substr(1, 2))).find(to_string(WHITE) + startLoc) != BOARD.at(8 - stoi(startLoc.substr(1, 2))).end() ? (to_string(WHITE) + startLoc) : (to_string(BLACK) + startLoc)], startLoc, endLoc)) {
        BOARD.at(8 - stoi(endLoc.substr(1, 2)))[BOARD.at(8 - stoi(endLoc.substr(1, 2))).find(to_string(WHITE) + endLoc) != BOARD.at(8 - stoi(endLoc.substr(1, 2))).end() ? (to_string(WHITE) + endLoc) : (to_string(BLACK) + endLoc)] = BOARD.at(8 - stoi(startLoc.substr(1, 2)))[BOARD.at(8 - stoi(startLoc.substr(1, 2))).find(to_string(WHITE) + startLoc) != BOARD.at(8 - stoi(startLoc.substr(1, 2))).end() ? (to_string(WHITE) + startLoc) : (to_string(BLACK) + startLoc)];
        BOARD.at(8 - stoi(startLoc.substr(1, 2)))[BOARD.at(8 - stoi(startLoc.substr(1, 2))).find(to_string(WHITE) + startLoc) != BOARD.at(8 - stoi(startLoc.substr(1, 2))).end() ? (to_string(WHITE) + startLoc) : (to_string(BLACK) + startLoc)] = Piece(-1);
        return true;
    }
    else {
        return false;
    }
}

bool BoardEngine::validateMove(Piece movedPiece, string startLoc, string endLoc) {
    return true;
}

void BoardEngine::printBoardText() {
    for (int i = 0; i < 8; ++i) {
        for (int j = 0; j < 8; ++j) {
            cout << board[i][j] << "\t";
        }
        cout << endl;
    }    
}


#endif