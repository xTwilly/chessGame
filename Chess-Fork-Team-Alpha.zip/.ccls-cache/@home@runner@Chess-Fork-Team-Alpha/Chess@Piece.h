#include "MoveRules.h"
#ifndef PIECE
#define PIECE

class Piece {
private:
    int color = -1;
    int pointValue = -1;
    bool hasMoved = false;
    MoveRules moveRules;
    string name = " ";
    string whiteChar = " ";
    string blackChar = " ";

protected:
    //Mutators
    void setColor(int color);
    void setPointValue(int ptVal);
    void setPieceName(string name);
    void setMoveState(bool moveState);
    void setMoveRules(MoveRules &moveRules);
    void setWhiteChar(string whiteChar);
    void setBlackChar(string blackChar);

public:
    // Constructors
    Piece() {}
    virtual ~Piece() {}

    //Accessors
    int getColor() const;
    int getPointValue() const;
    bool getMoveState() const;
    string getPieceName() const;
    string getMove(string startLoc, string endLoc);
    virtual const MoveRules getMoveRules() const;

    //Mutators

    //Functions
    virtual void displayDetails() const;
    virtual void onMove();

    //Unicode Functions for Piece Display
    virtual string getUnicodePiece(int color = -1) const;
};


int Piece::getColor() const {
    return color;
}

int Piece::getPointValue() const {
    return pointValue;
}

bool Piece::getMoveState() const {
    return hasMoved;
}

string Piece::getPieceName() const {
    return name;
}

string Piece::getMove(string startLoc, string endLoc) {
    return name + startLoc + ":" + endLoc + " ";
}

MoveRules const Piece::getMoveRules() const {
    return moveRules;
}

void Piece::setColor(int newColor) {
    enum pieceColor {WHITE, BLACK};
    color = (newColor == WHITE || newColor == BLACK)? newColor : -1;
}

void Piece::setPointValue(int ptVal) {
    enum pieceValue {KING = 0, PAWN = 1, KNIGHT = 3, BISHOP = 3, ROOK = 5, QUEEN = 9};
    pointValue = (ptVal == KING || ptVal == PAWN || ptVal == KNIGHT || ptVal == BISHOP || ptVal == ROOK || ptVal == QUEEN)? ptVal : -1;
}

void Piece::setMoveState(bool moveState) {
    hasMoved = moveState;
}

void Piece::setPieceName(string Name) {
    name = Name;
}

void Piece::setWhiteChar(string unicode) {
    whiteChar = unicode;
}

void Piece::setBlackChar(string unicode) {
    blackChar = unicode;
}

void Piece::setMoveRules(MoveRules &moveRule) {
    moveRules = moveRule;
}

//Updated displayDetails to use new functions
void Piece::displayDetails() const {
    cout << "Color: " << color << endl;
    cout << "Move Rules:" << endl;
    for (size_t i = 0; i < moveRules.size(); ++i) {
        cout << "    X: " << moveRules.getX(i) << ", Y: " << moveRules.getY(i) << endl;
    }
}

void Piece::onMove() {
    if (!hasMoved) {
        hasMoved = true;
    }
}

string Piece::getUnicodePiece(int color) const {
    enum pieceColor {WHITE, BLACK};
    return (color == WHITE)? whiteChar : (color == BLACK)? blackChar : name;
}

#endif