#include "../Common.h"
#ifndef MOVERULES
#define MOVERULES

class MoveRules {
private:
    vector<int> xMoves;
    vector<int> yMoves;

public:
    //Constructors
    MoveRules(vector<int> x, vector<int> y);
    MoveRules() {}
    ~MoveRules() {}
    
    //Accessors
    vector<int> const getAllX() const;
    vector<int> const getAllY() const;
    vector<int> const getPair(int index) const;
    int getX(int index) const;
    int getY(int index) const;

    //Mutators

    //Functions
    int size() const;
};

MoveRules::MoveRules(vector<int> x, vector<int> y) {
    if (x.size() == y.size()) {
        xMoves = x;
        yMoves = y;
    }
    else throw invalid_argument("Attempted construction of MoveRules object with invalid argument(s): Differing x- and y- sizes.");
}

int MoveRules::size() const {
    if (xMoves.size() == yMoves.size()) {
        return xMoves.size();
    }
    else throw runtime_error("Attempted return of MoveRule size with invalid MoveRule: Differing x- and y- sizes.");
}

vector<int> const MoveRules::getAllX() const {
    return xMoves;
}

vector<int> const MoveRules::getAllY() const {
    return yMoves;
}

vector<int> const MoveRules::getPair(int index) const {
    return vector<int> {getX(index), getY(index)};
}

int MoveRules::getX(int index) const {
    if (index < size()) {
        return xMoves.at(index);
    }
    else throw out_of_range("MoveRules field xMoves has no value corresponding to index " + to_string(index) + ".");
}

int MoveRules::getY(int index) const {
    if (index < size()) {
        return yMoves.at(index);
    }
    else throw out_of_range("MoveRules field yMoves has no value corresponding to index " + to_string(index) + ".");
}

#endif