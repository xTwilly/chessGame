#include "../Common.h"
#include "BoardEngine.h"

// int main() {
//     BoardEngine engine = BoardEngine();
//     //engine.printBoardText();
//     return 0;
// }