#include "Piece.h"
#include "MoveRules.h"
#include "../Common.h"
#ifndef PAWN
#define PAWN

class Pawn : public Piece {
public:
    Pawn(int color = -1);
    ~Pawn() {}

    //Move to BoardEngine
    bool canEnPassant(const int& currentRow, const int& targetRow) const {
        //assume that en passant is allowed if the pawn moved two squares forward
        return (abs(targetRow - currentRow) == 2);
    }

    //Move to BoardEngine
    void promotion() {
        //pawn must've reached the furthest row from their start, in the enemy territory
        //if condititions are true, replace this current pawn with a new piece of user choice (queen, rook, bishop, knight)
        //new piece doesn't have to be previously captured

        //if playerColor == "black" && thisPawn.startingPosition = somewhere in row 1{
        //cin>>userChoice
        //thisPiece.type = userChoice
        //}
        //else if playerColor == "white && thisPawn.startingPosition = somewhere in row 8{
        //cin>>userChoice
        //thisPiece.type = userChoice
        //}
    }

    void displayDetails() const override {
        cout << "Pawn Details:" << endl;
        Piece::displayDetails();
    }
};

Pawn::Pawn(int color) {
    setColor(color);
    setPointValue(1);
    setMoveState(false);
    setMoveRules(*(new MoveRules(vector<int> {0, 0, -1, 1}, vector<int> {1, 2,  1, 1})));
}

#endif