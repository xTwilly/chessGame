#include "Piece.h"
#include "MoveRules.h"
#include "../Common.h"
#ifndef KNIGHT
#define KNIGHT

class Knight : public Piece {
public:
    //Constructors
    Knight(int color = -1);
    ~Knight() {}

    //Functions
    void displayDetails() const override;
    string getMove(string startLoc, string endLoc);
};

Knight::Knight(int color) {
    setColor(color);
    setPointValue(3);
    setMoveState(false);
    setMoveRules(*(new MoveRules(vector<int> {-2, -1, 1, 2, -2, -1, 1, 2}, vector<int> {-1, -2, -2, -1, 1, 2, 2, 1})));
}

void Knight::displayDetails() const {
    cout << "Knight Details:" << endl;
    Piece::displayDetails();
}

string Knight::getMove(string startLoc, string endLoc) {
    return "N" + startLoc + ":" + endLoc;
}

#endif