#include "../Common.h"
#include "BoardEngine.h"

int main() {
    cout << "Welcome to our Chess Game!" << endl;
    BoardEngine("gameInstance" + to_string(getInt(-1, INT_MAX, "Enter the game instance you wish to load, \nor -1 to start a new game: ")) + ".txt");
    
    while (true) {
        cout << "Do you wish to play again?" << endl;
        cout << "1. Yes" << endl;
        cout << "2. No" << endl;
        
        switch (getInt(1, 2, "Enter your choice: ")) {
            case 1: {
                BoardEngine("gameInstance" + to_string(getInt(-1, INT_MAX, "Enter the game instance you wish to load, \nor -1 to start a new game: ")) + ".txt");
                break;
            }
            case 2: {
                cout << "Thank you for playing!" << endl;
                return 0;
                break;
            }
            default: {
                throw runtime_error("Main Replay Error: Unreachabe State");
            }
        }
    }
    
    return 0;
}