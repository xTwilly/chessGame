#include "Piece.h"
#ifndef PAWN
#define PAWN

class Pawn : public Piece {
private:
    bool enPassent = false;

public:
    //Constructors
    Pawn(int color = -1);
    ~Pawn() {}

    //Accessors
    bool canEnPassent() {return enPassent;}

    //Mutators

    //Functions
    void onMove() override;
    void displayDetails() const override {
        cout << "Pawn Details:" << endl;
        Piece::displayDetails();
    }
};

Pawn::Pawn(int color) {
    setColor(color);
    setPointValue(1);
    setMoveState(false);
    setPieceName("P");
    setWhiteChar("♙");
    setBlackChar("♟");
    setMoveRules(*(new MoveRules(vector<int> {0, 0,  -1, 1}, vector<int> {1, 2,  1, 1})));
}

void Pawn::onMove() {
    //If has moved
    if (getMoveState()) {
        enPassent = false;
    } else {
        setMoveState(true);
        enPassent = true;
    }
}
#endif