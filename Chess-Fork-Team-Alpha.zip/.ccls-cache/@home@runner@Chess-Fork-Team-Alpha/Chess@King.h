#include "Piece.h"
#ifndef KING
#define KING
class King : public Piece {
public:
    King(int color = -1);
    ~King() {}

    void displayDetails() const override {
        cout << "King Details:" << endl;
        Piece::displayDetails();
    }
};

King::King(int color) {
    setColor(color);
    setPointValue(0); //killing the king doesn't contribute to the point score
    setMoveState(false);
    setPieceName("K");
    setWhiteChar("♔");
    setBlackChar("♚");
    setMoveRules(*(new MoveRules(vector<int> {-1, 0, 1, -1, 1, -1, 0, 1, -2, 2}, vector<int> {1, 1, 1, 0, 0, -1, -1, -1, 0, 0})));
}
#endif