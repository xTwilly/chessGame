#include "Bishop.h"
#include "King.h"
#include "Knight.h"
#include "Pawn.h"
#include "Piece.h"
#include "Queen.h"
#include "Rook.h"
#ifndef BOARDENGINE
#define BOARDENGINE

class BoardEngine {
private:
  vector<map<string, Piece>> BOARD;
  array<array<string, 8>, 8> board;
  enum pieceColor { WHITE, BLACK };
  int turnCounter = 0;
  bool debug = false;
  // int whitePointsTotal = 0;
  // int blackPointsTotal = 0;

protected:
  void resetBoard();
  string createFiles(string filename);
  void fileInputSystem(string filename);
  void consoleInputSystem(string filename);
  bool validSyntax(string moveInfo);
  bool movePiece(string startLoc, string endLoc);
  bool validateMove(Piece movedPiece, string startLoc, string endLoc);
  bool inCheck();

public:
  // Constructors
  BoardEngine(string filename = "");
  ~BoardEngine() {}

  // Accessors
  vector<map<string, Piece>> getBoard() { return BOARD; }
  array<array<string, 8>, 8> getBoardInternal() { return board; }

  // Mutators

  // Functions
  void printBoardText(bool internal = false);
};

BoardEngine::BoardEngine(string filename) {
  resetBoard();
  filename = createFiles(filename);
  fileInputSystem(filename);
  consoleInputSystem(filename);
}

string BoardEngine::createFiles(string filename) {
  ofstream fileCreator;

  // Gets next game instance
  ifstream gameReader;
  string index;
  gameReader.open("Chess/games/gameIndex.txt");
  // Create new gameIndex if not found
  if (!gameReader.is_open()) {
    fileCreator.open("Chess/games/gameIndex.txt");
    fileCreator << "0";
    fileCreator.close();
    gameReader.open("Chess/games/gameIndex.txt");
    if (!gameReader.is_open()) {
      throw runtime_error("Cannot find gameIndex.txt");
    }
  }
  getline(gameReader, index);
  gameReader.close();

  // Updates filename to valid instance, if neccessary
  if (!(filename.find("gameInstance") == 0 &&
        isNum(filename.substr(string("gameInstance").length(),
                              filename.length() -
                                  string("gameInstance.txt").length())) &&
        stoi(filename.substr(string("gameInstance").length(),
                             filename.length() -
                                 string("gameInstance.txt").length())) <=
            stoi(index) &&
        stoi(filename.substr(string("gameInstance").length(),
                             filename.length() -
                                 string("gameInstance.txt").length())) >= 0)) {

    // Updates gameInstance.txt
    ofstream gameWriter;
    gameWriter.open("Chess/games/gameIndex.txt");
    if (!gameWriter.is_open()) {
      throw runtime_error("Cannot find gameIndex.txt");
    }
    gameWriter << to_string(stoi(index) + 1);
    gameWriter.close();

    // Creates new save file
    filename = "gameInstance" + to_string(stoi(index) + 1) + ".txt";
    fileCreator.open("Chess/games/" + filename);
    if (!fileCreator.is_open()) {
      throw runtime_error("Cannot find " + filename);
    }
    fileCreator.close();
  }

  // Move Notation explanation creator
  ifstream fileChecker("Chess/games/MoveNotation.txt");
  if (!fileChecker.is_open()) {
    // File does not exist
    goto createMoveNotation;
  } else {
    // File exists
    if (![&]() -> bool {
          string temp;
          getline(fileChecker, temp);
          return temp.length();
        }()) {
    // File is empty
    createMoveNotation:
      fileCreator.open("Chess/games/MoveNotation.txt");
      if (!fileCreator.is_open()) {
        throw runtime_error("Cannot find MoveNotation.txt");
      }
      // Populate MoveNotation.txt
      fileCreator << "Explanations of the file system..." << endl
                  << "Every game is stored in an individual file." << endl
                  << "Every move is stored on an individual row." << endl
                  << "White's move is at the beginning of the row." << endl
                  << "Black's move is at the end of the row." << endl
                  << "Moves follow the following syntax:" << endl
                  << "[Piece][Starting Location]:[Ending Location]." << endl
                  << "Where [Piece] is the following abbreviations:" << endl
                  << "{" << endl
                  << "\t"
                  << "P = Pawn" << endl
                  << "\t"
                  << "R = Rook" << endl
                  << "\t"
                  << "N = Knight" << endl
                  << "\t"
                  << "B = Bishop" << endl
                  << "\t"
                  << "Q = Queen" << endl
                  << "\t"
                  << "K = King" << endl
                  << "}" << endl
                  << "And Starting Location uses the Algebraic Notation" << endl
                  << "And Ending Location uses the Algebraic Notation, " << endl
                  << "With columns labeled on a grid between A-H" << endl
                  << "And rows labeled on a grid between 1-8";
    }
  }

  fileCreator.close();

  // Creates game instance file if not in directory
  fileCreator.open("Chess/games/" + filename, ofstream::app);
  if (!fileCreator.is_open()) {
    throw runtime_error("Cannot find " + filename);
  }
  fileCreator.close();

  // Returns updated filename
  return filename;
}

void BoardEngine::resetBoard() {
  map<string, Piece> tempMap;
  char letterList[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'};
  for (int i = 0; i < 8; ++i) {
    switch (i) {
    case 0: {
      for (int j = 0; j < 8; ++j) {
        switch (j) {
        case 0: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Rook(BLACK);
          break;
        }
        case 1: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Knight(BLACK);
          break;
        }
        case 2: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Bishop(BLACK);
          break;
        }
        case 3: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Queen(BLACK);
          break;
        }
        case 4: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = King(BLACK);
          break;
        }
        case 5: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Bishop(BLACK);
          break;
        }
        case 6: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Knight(BLACK);
          break;
        }
        case 7: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Rook(BLACK);
          break;
        }
        }
      }
      break;
    }
    case 1: {
      for (int j = 0; j < 8; ++j) {
        switch (j) {
        case 0: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(BLACK);
          break;
        }
        case 1: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(BLACK);
          break;
        }
        case 2: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(BLACK);
          break;
        }
        case 3: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(BLACK);
          break;
        }
        case 4: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(BLACK);
          break;
        }
        case 5: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(BLACK);
          break;
        }
        case 6: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(BLACK);
          break;
        }
        case 7: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(BLACK);
          break;
        }
        }
      }
      break;
    }
    case 2:
    case 3:
    case 4:
    case 5: {
      for (int j = 0; j < 8; ++j) {
        switch (j) {
        case 0: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Piece();
          break;
        }
        case 1: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Piece();
          break;
        }
        case 2: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Piece();
          break;
        }
        case 3: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Piece();
          break;
        }
        case 4: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Piece();
          break;
        }
        case 5: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Piece();
          break;
        }
        case 6: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Piece();
          break;
        }
        case 7: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Piece();
          break;
        }
        }
      }
      break;
    }
    case 6: {
      for (int j = 0; j < 8; ++j) {
        switch (j) {
        case 0: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(WHITE);
          break;
        }
        case 1: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(WHITE);
          break;
        }
        case 2: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(WHITE);
          break;
        }
        case 3: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(WHITE);
          break;
        }
        case 4: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(WHITE);
          break;
        }
        case 5: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(WHITE);
          break;
        }
        case 6: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(WHITE);
          break;
        }
        case 7: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Pawn(WHITE);
          break;
        }
        }
      }
      break;
    }
    case 7: {
      for (int j = 0; j < 8; ++j) {
        switch (j) {
        case 0: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Rook(WHITE);
          break;
        }
        case 1: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Knight(WHITE);
          break;
        }
        case 2: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Bishop(WHITE);
          break;
        }
        case 3: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Queen(WHITE);
          break;
        }
        case 4: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = King(WHITE);
          break;
        }
        case 5: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Bishop(WHITE);
          break;
        }
        case 6: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Knight(WHITE);
          break;
        }
        case 7: {
          tempMap[to_string((i % 2 == j % 2) ? WHITE : BLACK) + letterList[j] +
                  to_string(8 - i)] = Rook(WHITE);
          break;
        }
        }
      }
      break;
    }
    default: {
      break;
    }
    }
    BOARD.push_back(tempMap);
    tempMap.clear();
  }
}

bool BoardEngine::validSyntax(string moveInfo) {
  // Input size check
  if (moveInfo.length() != 6) {
    if (debug) {
      cout << "Size Check Failed" << endl;
    }
    return false;
  }

  // Piece name check
  if (getValue(moveInfo, 0, false) != 'P' &&
      getValue(moveInfo, 0, false) != 'R' &&
      getValue(moveInfo, 0, false) != 'N' &&
      getValue(moveInfo, 0, false) != 'B' &&
      getValue(moveInfo, 0, false) != 'Q' &&
      getValue(moveInfo, 0, false) != 'K') {

    if (debug) {
      cout << "Name Check Failed" << endl;
    }
    return false;
  }

  // Piece Col Check
  if (static_cast<int>(getValue(moveInfo, 1, false)) < static_cast<int>('A') ||
      static_cast<int>(getValue(moveInfo, 1, false)) > static_cast<int>('H') ||
      static_cast<int>(getValue(moveInfo, 4, false)) < static_cast<int>('A') ||
      static_cast<int>(getValue(moveInfo, 4, false)) > static_cast<int>('H')) {

    if (debug) {
      cout << "Col Check Failed" << endl;
    }
    return false;
  }

  // Piece Row Check
  if (static_cast<int>(getValue(moveInfo, 2, false)) < static_cast<int>('1') ||
      static_cast<int>(getValue(moveInfo, 2, false)) > static_cast<int>('8') ||
      static_cast<int>(getValue(moveInfo, 5, false)) < static_cast<int>('1') ||
      static_cast<int>(getValue(moveInfo, 5, false)) > static_cast<int>('8')) {

    if (debug) {
      cout << "Row Check Failed" << endl;
    }
    return false;
  }

  // Colon Check
  if (getValue(moveInfo, 3, false) != ':') {
    if (debug) {
      cout << "Colon Check Failed" << endl;
    }
    return false;
  }

  // All chars valid
  return true;
}

bool BoardEngine::movePiece(string startLoc, string endLoc) {
  if (validateMove(
          BOARD.at(8 - stoi(startLoc.substr(
                           1)))[(BOARD.at(8 - stoi(startLoc.substr(1)))
                                     .find(to_string(WHITE) + startLoc) !=
                                 BOARD.at(8 - stoi(startLoc.substr(1))).end())
                                    ? (to_string(WHITE) + startLoc)
                                    : (to_string(BLACK) + startLoc)],
          startLoc, endLoc)) {

    BOARD.at(
        8 - stoi(endLoc.substr(1)))[(BOARD.at(8 - stoi(endLoc.substr(1)))
                                         .find(to_string(WHITE) + endLoc) !=
                                     BOARD.at(8 - stoi(endLoc.substr(1))).end())
                                        ? (to_string(WHITE) + endLoc)
                                        : (to_string(BLACK) + endLoc)] =
        BOARD.at(8 - stoi(startLoc.substr(
                         1)))[(BOARD.at(8 - stoi(startLoc.substr(1)))
                                   .find(to_string(WHITE) + startLoc) !=
                               BOARD.at(8 - stoi(startLoc.substr(1))).end())
                                  ? (to_string(WHITE) + startLoc)
                                  : (to_string(BLACK) + startLoc)];

    BOARD.at(8 - stoi(startLoc.substr(
                     1)))[(BOARD.at(8 - stoi(startLoc.substr(1)))
                               .find(to_string(WHITE) + startLoc) !=
                           BOARD.at(8 - stoi(startLoc.substr(1))).end())
                              ? (to_string(WHITE) + startLoc)
                              : (to_string(BLACK) + startLoc)] = Piece();

    BOARD
        .at(8 -
            stoi(endLoc.substr(1)))[(BOARD.at(8 - stoi(endLoc.substr(1)))
                                         .find(to_string(WHITE) + endLoc) !=
                                     BOARD.at(8 - stoi(endLoc.substr(1))).end())
                                        ? (to_string(WHITE) + endLoc)
                                        : (to_string(BLACK) + endLoc)]
        .onMove();
    return true;
  } else {
    return false;
  }
}

// Assumes startLoc and endLoc are on the board
// FIXME: Breaking errors in MoveRule validation
// TODO: First move handling: Pawn, Castling; En Passent
bool BoardEngine::validateMove(Piece movedPiece, string startLoc,
                               string endLoc) {
  string genFlag = "";
  // Piece color checker, with exception for threat validation
  if (BOARD.at(8 - stoi(endLoc.substr(
                       1)))[(BOARD.at(8 - stoi(endLoc.substr(1)))
                                 .find(to_string(WHITE) + endLoc) !=
                             BOARD.at(8 - stoi(endLoc.substr(1))).end())
                                ? (to_string(WHITE) + endLoc)
                                : (to_string(BLACK) + endLoc)]
              .getPieceName() != "K" &&
      movedPiece.getColor() != (turnCounter % 2 == 0 ? WHITE : BLACK)) {
    if (debug) {
      cout << "Invalid Move: Piece is not of the correct color." << endl;
    }
    return false;
  } else if (debug) {
    cout << "Validate Moves: Color Test Passed" << endl;
  }

  // Weeds out empty pieces, and pieces without a valid movement path to endLoc
  // Iterates ruleIndex to a valid rule
  int ruleIndex = 0;
  do {
    if (ruleIndex == movedPiece.getMoveRules().size()) {
      return false;
    }
  } while ((movedPiece.getMoveRules().getX(ruleIndex) !=
                static_cast<int>(getValue(startLoc, 0, false)) -
                    static_cast<int>(getValue(endLoc, 0, false)) ||
            movedPiece.getMoveRules().getY(ruleIndex) !=
                (stoi(startLoc.substr(1)) - stoi(endLoc.substr(1))) *
                    ((movedPiece.getColor() == WHITE)
                         ? -1
                         : ((movedPiece.getColor() == BLACK)
                                ? 1
                                : throw runtime_error("Invalid: No Piece at " +
                                                      startLoc))))
               ? ++ruleIndex
               : false);

  if (debug) {
    cout << "ruleIndex: " << ruleIndex << endl;
    cout << "X: " << movedPiece.getMoveRules().getX(ruleIndex) << endl;
    cout << "Y: " << movedPiece.getMoveRules().getY(ruleIndex) << endl;
  }

  // Check for intermediate pieces:
  if (movedPiece.getPieceName() != "N") {
    // Find numElementsBetween
    for (int i = 1; i < max(abs(movedPiece.getMoveRules().getX(ruleIndex)),
                            abs(movedPiece.getMoveRules().getY(ruleIndex)));
         ++i) {
      string intermediateLoc =
          string(1, static_cast<char>(
                        static_cast<int>(getValue(startLoc, 0)) -
                        (i * movedPiece.getMoveRules().getX(ruleIndex) /
                         max(abs(movedPiece.getMoveRules().getX(ruleIndex)),
                             abs(movedPiece.getMoveRules().getY(ruleIndex))))))
              .append(to_string(
                  stoi(startLoc.substr(1)) -
                  ((i * movedPiece.getMoveRules().getY(ruleIndex) /
                    max(abs(movedPiece.getMoveRules().getX(ruleIndex)),
                        abs(movedPiece.getMoveRules().getY(ruleIndex)))) *
                   ((movedPiece.getColor() == WHITE) ? -1 : 1))));

      if (BOARD
              .at(8 -
                  stoi(intermediateLoc.substr(
                      1)))[(BOARD.at(8 - stoi(intermediateLoc.substr(1)))
                                .find(to_string(WHITE) + intermediateLoc) !=
                            BOARD.at(8 - stoi(intermediateLoc.substr(1))).end())
                               ? (to_string(WHITE) + intermediateLoc)
                               : (to_string(BLACK) + intermediateLoc)]
              .getPieceName() != " ") {
        if (debug) {
          cout << "Invalid Move: Intermediate Piece Detected" << endl;
        }
        return false;
      }
    }
  }

  // Special Piece handeling
  // Pawn
  if (movedPiece.getPieceName() == "P") {
    // First Move  //If pawn has moved, forbid double move
    if (movedPiece.getMoveState() && ruleIndex == 1) {
      return false;
    }

    // Obstacle
    if ((ruleIndex == 0 || ruleIndex == 1) &&
        BOARD.at(8 - stoi(endLoc.substr(
                         1)))[(BOARD.at(8 - stoi(endLoc.substr(1)))
                                   .find(to_string(WHITE) + endLoc) !=
                               BOARD.at(8 - stoi(endLoc.substr(1))).end())
                                  ? (to_string(WHITE) + endLoc)
                                  : (to_string(BLACK) + endLoc)]
                .getColor() == abs(movedPiece.getColor() - 1)) {
      return false;
    }

    // Attacking
    if ((ruleIndex == 2 || ruleIndex == 3) /*&& !enPassent*/ &&
        BOARD.at(8 - stoi(endLoc.substr(
                         1)))[(BOARD.at(8 - stoi(endLoc.substr(1)))
                                   .find(to_string(WHITE) + endLoc) !=
                               BOARD.at(8 - stoi(endLoc.substr(1))).end())
                                  ? (to_string(WHITE) + endLoc)
                                  : (to_string(BLACK) + endLoc)]
                .getColor() == -1) {
      return false;
    }

    // Promotion
    if ((endLoc.substr(1) == "8" && movedPiece.getColor() == WHITE) ||
        (endLoc.substr(1) == "1" && movedPiece.getColor() == BLACK)) {
      // Delay promotion until move validity is confirmed
      genFlag.append("Promotion: TRUE");
    }
  } else if (movedPiece.getPieceName() == "K" && (ruleIndex >= 8) &&
             !movedPiece.getMoveState()) {
    if (ruleIndex == 8 &&
        BOARD.at(7 - movedPiece.getColor() *
                         7)[to_string(movedPiece.getColor()) + "F" +
                            to_string(7 - movedPiece.getColor() * 7)]
                .getColor() == -1 &&
        BOARD.at(7 - movedPiece.getColor() *
                         7)[to_string(abs(movedPiece.getColor() - 1)) + "G" +
                            to_string(7 - movedPiece.getColor() * 7)]
                .getColor() == -1 &&
        BOARD.at(7 - movedPiece.getColor() *
                         7)[to_string(movedPiece.getColor()) + "H" +
                            to_string(7 - movedPiece.getColor() * 7)]
                .getColor() == movedPiece.getColor() &&
        BOARD.at(7 - movedPiece.getColor() *
                         7)[to_string(movedPiece.getColor()) + "H" +
                            to_string(7 - movedPiece.getColor() * 7)]
                .getPieceName() == "R") {
      // King sided Castling
      BOARD.at(7 - movedPiece.getColor() *
                       7)[to_string(movedPiece.getColor()) + "F" +
                          to_string(7 - movedPiece.getColor() * 7)] =
          Rook(movedPiece.getColor());
      BOARD.at(7 - movedPiece.getColor() *
                       7)[to_string(movedPiece.getColor()) + "H" +
                          to_string(7 - movedPiece.getColor() * 7)] = Piece();
    } else if (ruleIndex == 9 &&
               BOARD.at(7 - movedPiece.getColor() *
                                7)[to_string(movedPiece.getColor()) + "D" +
                                   to_string(7 - movedPiece.getColor() * 7)]
                       .getColor() == -1 &&
               BOARD.at(7 -
                        movedPiece.getColor() *
                            7)[to_string(abs(movedPiece.getColor() - 1)) + "C" +
                               to_string(7 - movedPiece.getColor() * 7)]
                       .getColor() == -1 &&
               BOARD.at(7 - movedPiece.getColor() *
                                7)[to_string(movedPiece.getColor()) + "B" +
                                   to_string(7 - movedPiece.getColor() * 7)]
                       .getColor() == -1 &&
               BOARD.at(7 -
                        movedPiece.getColor() *
                            7)[to_string(abs(movedPiece.getColor() - 1)) + "A" +
                               to_string(7 - movedPiece.getColor() * 7)]
                       .getColor() == movedPiece.getColor() &&
               BOARD.at(7 -
                        movedPiece.getColor() *
                            7)[to_string(abs(movedPiece.getColor() - 1)) + "A" +
                               to_string(7 - movedPiece.getColor() * 7)]
                       .getPieceName() == "R") {
      // Queen sided Castling
      BOARD.at(7 - movedPiece.getColor() *
                       7)[to_string(movedPiece.getColor()) + "D" +
                          to_string(7 - movedPiece.getColor() * 7)] =
          Rook(movedPiece.getColor());
      BOARD.at(7 - movedPiece.getColor() *
                       7)[to_string(abs(movedPiece.getColor() - 1)) + "A" +
                          to_string(7 - movedPiece.getColor() * 7)] = Piece();
    } else {
      return false;
    }
  }

  // Amicide prevention
  if (BOARD
          .at(8 - stoi(endLoc.substr(
                      1)))[(BOARD.at(8 - stoi(endLoc.substr(1)))
                                .find(to_string(WHITE) + endLoc) !=
                            BOARD.at(8 - stoi(endLoc.substr(1))).end())
                               ? (to_string(WHITE) + endLoc)
                               : (to_string(BLACK) + endLoc)]
          .getColor() == movedPiece.getColor()) {
    return false;
  }

  // Prevent recursive calls
  // Check handeling
  if (BOARD.at(8 - stoi(endLoc.substr(
                       1)))[(BOARD.at(8 - stoi(endLoc.substr(1)))
                                 .find(to_string(WHITE) + endLoc) !=
                             BOARD.at(8 - stoi(endLoc.substr(1))).end())
                                ? (to_string(WHITE) + endLoc)
                                : (to_string(BLACK) + endLoc)]
              .getPieceName() != "K" &&
      inCheck()) {
    // Store current board state
    map<string, Piece> moveHolder;
    moveHolder.insert(pair<string, Piece>(startLoc, movedPiece));
    moveHolder.insert(pair<string, Piece>(
        endLoc,
        BOARD.at(8 - stoi(endLoc.substr(
                         1)))[(BOARD.at(8 - stoi(endLoc.substr(1)))
                                   .find(to_string(WHITE) + endLoc) !=
                               BOARD.at(8 - stoi(endLoc.substr(1))).end())
                                  ? (to_string(WHITE) + endLoc)
                                  : (to_string(BLACK) + endLoc)]));

    // Simulate Move
    BOARD.at(
        8 -
        stoi(moveHolder.begin()->first.substr(
            1)))[(BOARD.at(8 - stoi(moveHolder.begin()->first.substr(1)))
                      .find(to_string(WHITE) + moveHolder.begin()->first) !=
                  BOARD.at(8 - stoi(moveHolder.begin()->first.substr(1))).end())
                     ? (to_string(WHITE) + moveHolder.begin()->first)
                     : (to_string(BLACK) + moveHolder.begin()->first)] =
        Piece();

    BOARD.at(
        8 -
        stoi(moveHolder.end()->first.substr(
            1)))[(BOARD.at(8 - stoi(moveHolder.end()->first.substr(1)))
                      .find(to_string(WHITE) + moveHolder.end()->first) !=
                  BOARD.at(8 - stoi(moveHolder.end()->first.substr(1))).end())
                     ? (to_string(WHITE) + moveHolder.end()->first)
                     : (to_string(BLACK) + moveHolder.end()->first)] =
        moveHolder.begin()->second;

    // Check king status after move
    if (BOARD.at(8 - stoi(endLoc.substr(
                         1)))[(BOARD.at(8 - stoi(endLoc.substr(1)))
                                   .find(to_string(WHITE) + endLoc) !=
                               BOARD.at(8 - stoi(endLoc.substr(1))).end())
                                  ? (to_string(WHITE) + endLoc)
                                  : (to_string(BLACK) + endLoc)]
                .getPieceName() != "K" &&
        inCheck()) {
      // Set return flag to false
      genFlag.append("Return: FALSE");
    }
    // Restore Board State
    BOARD.at(
        8 -
        stoi(moveHolder.begin()->first.substr(
            1)))[(BOARD.at(8 - stoi(moveHolder.begin()->first.substr(1)))
                      .find(to_string(WHITE) + moveHolder.begin()->first) !=
                  BOARD.at(8 - stoi(moveHolder.begin()->first.substr(1))).end())
                     ? (to_string(WHITE) + moveHolder.begin()->first)
                     : (to_string(BLACK) + moveHolder.begin()->first)] =
        moveHolder.begin()->second;

    BOARD.at(
        8 -
        stoi(moveHolder.end()->first.substr(
            1)))[(BOARD.at(8 - stoi(moveHolder.end()->first.substr(1)))
                      .find(to_string(WHITE) + moveHolder.end()->first) !=
                  BOARD.at(8 - stoi(moveHolder.end()->first.substr(1))).end())
                     ? (to_string(WHITE) + moveHolder.end()->first)
                     : (to_string(BLACK) + moveHolder.end()->first)] =
        moveHolder.end()->second;

    // Check return flag
    if (genFlag.find("Return: FALSE") != string::npos) {
      cout << "Invalid: King remains in check." << endl;
      return false;
    }
  }

  // Check promotion flag
  if (genFlag.find("Promotion: TRUE") != string::npos) {
    // Promote
    // TODO: Change all row substrings to have length 1
    // Add promotion info to end of string
    // If promotion info is not provided, assume consoleInputSystem is active
  }

  return true;
}

bool BoardEngine::inCheck() {
  // Get King's position. MG 4/20/24
  map<string, Piece> kingMap;
  kingMap.clear(); // Precaution, should not be needed
  for (int i = 0; i < BOARD.size(); ++i) {
    for (map<string, Piece>::iterator j = BOARD.at(i).begin();
         j != BOARD.at(i).end(); ++j) {
      if (j->second.getPieceName() == "K" &&
          j->second.getColor() == ((turnCounter % 2 == 0) ? WHITE : BLACK)) {
        kingMap.insert(pair<string, Piece>(j->first, j->second));
        break;
      }
    }
  }

  // Check for threats against the king
  for (int i = 0; i < BOARD.size(); ++i) {
    for (map<string, Piece>::iterator j = BOARD.at(i).begin();
         j != BOARD.at(i).end(); ++j) {
      if (j->second.getColor() == abs(kingMap.begin()->second.getColor() - 1) &&
          validateMove(j->second, j->first.substr(1),
                       kingMap.begin()->first.substr(1))) {
        return true;
      }
    }
  }
  return false;
}

void BoardEngine::fileInputSystem(string filename) {
  cout << endl
       << "Starting game instance #"
       << substring(filename, string("gameInstance").length(),
                    filename.find(".txt"), false)
       << endl;

  ifstream moveReader;
  moveReader.open("Chess/games/" + filename);
  if (!moveReader.is_open()) {
    throw runtime_error("Cannot find " + filename);
  }

  // Reads all moves from file
  // FIXME: Check always triggers.  /*ios::app?*/
  if (!moveReader.eof()) {
    cout << "Loading moves from file..." << endl;
  }
  printBoardText();

  string moveInfo;
  while (getline(moveReader, moveInfo, ' ')) {
    // Strips newline characters
    if (moveInfo.at(0) == '\n') {
      moveInfo = moveInfo.substr(1);
    }

    if (validSyntax(moveInfo)) {
      if (movePiece(substring(moveInfo, 1, moveInfo.find(":"), false),
                    substring(moveInfo, moveInfo.find(":") + 1, -1, false))) {
        cout << endl
             << ((turnCounter % 2 == 0) ? "White " : "Black ") << "to Move."
             << endl;
        cout << "Input Move: " << moveInfo << endl;
        printBoardText();
        turnCounter++;
      } else {
        cout << endl << "Input Move: Invalid" << endl;
        cout << "Switching to user input mode." << endl;
        moveReader.seekg(0, ios::end);
      }
    } else {
      cout << endl << "Input Move: Invalid" << endl;
      cout << "Switching to user input mode." << endl;
      moveReader.seekg(0, ios::end);
    }
  }

  moveReader.close();
}

void BoardEngine::consoleInputSystem(string filename) {
  // Open the file in append mode
  ofstream outputFile;
  outputFile.open("Chess/games/" + filename, ios::app);
  if (!outputFile.is_open()) {
    throw runtime_error("Cannot find " + filename);
  }

  cout << endl << "Beginning live playthrough..." << endl;

  // Gets moves from console
  string moveInfo = " ";
  while (moveInfo != "") {
    // Get move
    cout << endl
         << ((turnCounter % 2 == 0) ? "White " : "Black ") << "to Move."
         << endl;
    cout << "Input Move: ";
    cin >> moveInfo;
    //    getline(cin, moveInfo);
    // Precaution, should not be needed
    if (moveInfo.at(0) == '\n') {
      moveInfo = moveInfo.substr(1);
    }

    // Perform move
    if (validSyntax(moveInfo)) {
      if (movePiece(substring(moveInfo, 1, moveInfo.find(':'), false),
                    substring(moveInfo, moveInfo.find(':') + 1, -1, false))) {
        printBoardText();
        // Display Move to Console
        // cout << "Move made: " << moveInfo << endl;

        // Writing moves to file
        outputFile << ((turnCounter % 2 == WHITE && turnCounter != 0) ? "\n"
                                                                      : "")
                   << moveInfo << " " << flush;

        // Switch to next player
        turnCounter++;
      } else {
        // Get new move
        continue;
      }
    } else {
      // Treat invalid move as resignation attempt
      cout << endl << "Invalid move.  Do you wish to resign? (Y/N): ";
      cin >> moveInfo;
      //      getline(cin, moveInfo);
      if (moveInfo.at(0) == '\n') {
        moveInfo = moveInfo.substr(1);
      }

      // Confirm resignation attempt: Any input starting with y.
      if (toupper(getValue(moveInfo, 0, false)) == 'Y') {
        cout << endl
             << "Game Over! "
             << ((--turnCounter % 2 == 0) ? "White " : "Black ")
             << "Won! CONGRATULATIONS!!" << endl;
        // Breaks while loop
        moveInfo = "";
        continue;
      } else {
        // Get new move
        continue;
      }
    }
  }
  outputFile.close();
}

void BoardEngine::printBoardText(bool internal) {
  cout << "===================================== " << endl;
  cout << "------------ Chess Board ------------ " << endl;
  cout << "===================================== " << endl;

  // Print Column headers
  for (int i = static_cast<int>('A'); i <= static_cast<int>('H'); ++i) {
    cout << "\t  " << static_cast<char>(i);
  }

  // Print board
  cout << endl << "\t--------------------------------- " << endl;
  for (int i = 0; i < BOARD.size(); ++i) {
    // Print row headers
    cout << to_string(8 - i);
    // NOTE: BOARD alphabetized by square color
    for (int j = 0; j < BOARD.at(i).size() / 2; ++j) {
      // Print even columns
      auto it = BOARD.at(i).begin();
      advance(it, (i % 2 == 0) ? j : j + 4);
      cout << "\t| "
           << ((internal) ? it->first
                          : it->second.getUnicodePiece(it->second.getColor()));

      // Print odd columns
      it = BOARD.at(i).begin();
      advance(it, (i % 2 == 0) ? j + 4 : j);
      cout << "\t| "
           << ((internal) ? it->first
                          : it->second.getUnicodePiece(it->second.getColor()));
    }
    cout << "\t|" << endl << "\t--------------------------------- " << endl;
  }
}

#endif