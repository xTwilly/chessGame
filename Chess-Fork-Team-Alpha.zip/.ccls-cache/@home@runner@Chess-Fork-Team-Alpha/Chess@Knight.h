#include "Piece.h"
#ifndef KNIGHT
#define KNIGHT

class Knight : public Piece {
public:
    //Constructors
    Knight(int color = -1);
    ~Knight() {}

    //Functions
    void displayDetails() const override;
};

Knight::Knight(int color) {
    setColor(color);
    setPointValue(3);
    setMoveState(false);
    setPieceName("N");
    setWhiteChar("♘");
    setBlackChar("♞");
    setMoveRules(*(new MoveRules(vector<int> {-2, -1, 1, 2, -2, -1, 1, 2}, vector<int> {-1, -2, -2, -1, 1, 2, 2, 1})));
}

void Knight::displayDetails() const {
    cout << "Knight Details:" << endl;
    Piece::displayDetails();
}


#endif