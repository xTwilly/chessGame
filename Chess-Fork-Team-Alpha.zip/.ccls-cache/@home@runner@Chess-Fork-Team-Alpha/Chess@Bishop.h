#include "Piece.h"
#ifndef BISHOP
#define BISHOP
class Bishop : public Piece {
public:
    Bishop(int color = -1);
    ~Bishop() {}

    void displayDetails() const override {
        cout << "Bishop Details:" << endl;
        Piece::displayDetails();
    }
};

Bishop::Bishop(int color) {
    setColor(color);
    setPointValue(3);
    setMoveState(false);
    setPieceName("B");
    setWhiteChar("♗");
    setBlackChar("♝");
    setMoveRules(*(new MoveRules(vector<int>{1, 2, 3, 4, 5, 6, 7, -1, -2, -3, -4, -5, -6, -7, -1, -2, -3, -4, -5, -6, -7, 1, 2, 3, 4, 5, 6, 7}, vector<int>{-1, -2, -3, -4, -5, -6, -7, -1, -2, -3, -4, -5, -6, -7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7})));
}

#endif