#include "Piece.h"
//#include "MoveRules.h"
//#include "../Common.h"
#ifndef ROOK
#define ROOK

class Rook : public Piece {
public:
    Rook(int color = -1);
    ~Rook() {}

    void displayDetails() const override {
        cout << "Rook Details:" << endl;
        Piece::displayDetails();
    }
};

Rook::Rook(int color) {
    setColor(color);
    setPointValue(5);
    setMoveState(false);
    setPieceName("R");
    setWhiteChar("♖");
    setBlackChar("♜");
    setMoveRules(*(new MoveRules(vector<int> { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, -1, -2, -3, -4, -5, -6, -7}, vector<int> {1, 2, 3, 4, 5, 6, 7, -1, -2, -3, -4, -5, -6, -7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0})));
}
#endif

/*
 Here are the rules for castling: 

Your king can not have moved- Once your king moves, you can no longer castle, even if you move the king back to the starting square. Many strategies involve forcing the opponent’s king to move just for this reason. 

Your rook can not have moved- If you move your rook, you can’t castle on that side anymore. Both the king and the rook you are castling with can’t have moved. 

Your king can NOT be in check- Though castling often looks like an appealing escape, you can’t castle while you are in check! Once you are out of check, then you can castle. Unlike moving, being checked does not remove the ability to castle later. 

Your king can not pass through check- If any square the king moves over or moves onto would put you in check, you can’t castle. You’ll have to get rid of that pesky attacking piece first!

No pieces can be between the king and rook- All the spaces between the king and rook must be empty. This is part of why it’s so important to get your pieces out into the game as soon as possible! 

*/