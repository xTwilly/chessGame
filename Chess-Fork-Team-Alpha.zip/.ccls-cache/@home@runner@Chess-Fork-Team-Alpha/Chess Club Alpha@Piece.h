#include "../Common.h"
#include "MoveRules.h"
#ifndef PIECE
#define PIECE

class Piece {
private:
    int color = -1;
    int pointValue = -1;
    bool hasMoved = false;
    MoveRules moveRules;
    
protected:
    //Mutators
    void setColor(int color);
    void setPointValue(int ptVal);
    void setMoveRules(MoveRules &moveRules);

public:
    // Constructors
    Piece(int color = -1, int pointValue = -1, bool hasMoved = false) : color(color), pointValue(pointValue), hasMoved(hasMoved) {}
    ~Piece() {}

    //Accessors
    int getColor() const;
    int getPointValue() const;
    bool getMoveState();
    virtual const MoveRules getMoveRules() const;

    //Mutators
    void setMoveState(bool moveState);


    //Functions
    virtual void displayDetails() const;
    virtual void onFirstMove();
};


int Piece::getColor() const {
    return color;
}

int Piece::getPointValue() const {
    return pointValue;
}

bool Piece::getMoveState() {
    return hasMoved;
}

MoveRules const Piece::getMoveRules() const {
    return moveRules;
}

void Piece::setColor(int newColor) {
    enum pieceColor {WHITE, BLACK};
    color = (newColor == WHITE || newColor == BLACK)? newColor : -1;
}

void Piece::setPointValue(int ptVal) {
    enum pieceValue {KING = 0, PAWN = 1, KNIGHT = 3, BISHOP = 3, ROOK = 5, QUEEN = 9};
    pointValue = (ptVal == KING || ptVal == PAWN || ptVal == KNIGHT || ptVal == BISHOP || ptVal == ROOK || ptVal == QUEEN)? ptVal : -1;
}

void Piece::setMoveState(bool moveState) {
    hasMoved = moveState;
}

void Piece::setMoveRules(MoveRules &moveRule) {
    moveRules = moveRule;
}

//Updated displayDetails to use new functions
void Piece::displayDetails() const {
    cout << "Color: " << color << endl;
    cout << "Move Rules:" << endl;
    for (size_t i = 0; i < moveRules.size(); ++i) {
        cout << "    X: " << moveRules.getX(i) << ", Y: " << moveRules.getY(i) << endl;
    }
}

void Piece::onFirstMove() {
    if (!hasMoved) {
        hasMoved = true;
    }
}

#endif