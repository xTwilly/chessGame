//Yousef Al-Bakri, yalbakri@dmacc.edu
//Useful cross-program functions

//Guard
#ifndef COMMON
#define COMMON

//Preprocesser Initializations
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <cmath>
#include <string>
#include <cctype>
#include <array>
#include <vector>
#include <cfloat>
#include <climits>
#include <iterator>
#include <map>
#include <algorithm>
using namespace std;

/**
  Prompts the user for a number until a valid input is recieved.
  @param minValue  The minimum allowed value.  Default: –2147483648
  @param maxValue  The maximum allowed value.  Default:  2147483647
  @param prompt  The prompt to output to the user.  Default: "Please input an integer: "
  @param error  The response to invalid input.  Default: "Invalid input.  "
  @param boundError  The response to inputs larger than int bounds.  Default: "Out of bounds.  "
  @param genError  The response to errors the code does not handle.  Default: "Unknown error.  " 
  @return  A valid number with a user-inputed value
*/
int getInt(int minValue = INT_MIN, int maxValue = INT_MAX,                                       
 string prompt = "Please input an integer: ", string error = "Invalid input.  ", 
 string boundError = "Out of bounds.  ", string genError = "Unknown error.  ") {
  string input;
  bool valid = false;

  while (!valid) {
    try {
      start:
      cout << prompt;
      cin >> input;
  
      if (input.find("--") != string::npos) {
        cout << error;
        continue;
      }
      for (int i = 0; i < static_cast<int>(input.length()); ++i) {
        if(!isdigit(input.at(i)) && input.at(i) != '-') {
          cout << error;
          goto start;
        }
      }
      if (stoi(input) > maxValue || stoi(input) < minValue) {
        cout << error;
        continue;
      }
      else {
        valid = true;
      }
    }
      catch(out_of_range const&) {
        cout << boundError;
      }
      catch(...) {
        cout << genError;
      }
  }

  return stoi(input);
}



/**
  Allows the getInt method to specify messages without changing the default range.
  @param prompt  The prompt to output to the user.  No default for overload clarity.
  @param error  The response to invalid input.  Default: "Invalid input.  "
  @param minValue  The minimum allowed value.  Default: –2147483648
  @param maxValue  The maximum allowed value.  Default:  2147483647
  @param boundError  The response to inputs larger than int bounds.  Default: "Out of bounds.  "
  @param genError  The response to errors the code does not handle.  Default: "Unknown error.  " 
  @return  A valid number with a user-inputed value
*/
int getInt(string prompt, string error = "Invalid input.  ", int minValue = INT_MIN, 
 int maxValue = INT_MAX, string boundError = "Out of bounds.  ", string genError = "Unknown error.  ") {
  string input;
  bool valid = false;

  while (!valid) {
    try {
      start:
      cout << prompt;
      cin >> input;
  
      if (input.find("--") != string::npos) {
        cout << error;
        continue;
      }
      for (int i = 0; i < static_cast<int>(input.length()); ++i) {
        if(!isdigit(input.at(i)) && input.at(i) != '-') {
          cout << error;
          goto start;
        }
      }
      if (stoi(input) > maxValue || stoi(input) < minValue) {
        cout << error;
        continue;
      }
      else {
        valid = true;
      }
    }
      catch(out_of_range const&) {
        cout << boundError;
      }
      catch(...) {
        cout << genError;
      }
  }

  return stoi(input);
}



/**
  Prompts the user for a number until a valid input is recieved.
  @param minValue  The minimum allowed value.  Default: 2.22507*10^-308
  @param maxValue  The maximum allowed value.  Default: 1.79769*10^+308
  @param prompt  The prompt to output to the user.  Default: "Please input a number: "
  @param error  The response to invalid input.  Default: "Invalid input.  "
  @param boundError  The response to inputs larger than int bounds.  Default: "Out of bounds.  "
  @param genError  The response to errors the code does not handle.  Default: "Unknown error.  " 
  @return  A valid number with a user-inputed value
*/
double getDouble(double minValue = -DBL_MAX, double maxValue = DBL_MAX,                          
 string prompt = "Please input a number: ", string error = "Invalid input.  ", 
 string boundError = "Out of bounds.  ", string genError = "Unknown error.  ") {
  string input;
  bool valid = false;

  while (!valid) {
    try {
      start:
      cout << prompt;
      cin >> input;
  
      if (input.find("--") != string::npos) {
        cout << error;
        continue;
      }
      for (int i = 0; i < static_cast<int>(input.length()); ++i) {
        if(!isdigit(input.at(i)) && input.at(i) != '.' && input.at(i) != '-') {
          cout << error;
          goto start;
        }
      }
      if (stod(input) > maxValue || stod(input) < minValue) {
        cout << error;
        goto start;
      }
      else {
        valid = true;
      }
    }
      catch(out_of_range const&) {
        cout << boundError;
      }
      catch(...) {
        cout << genError;
      }
  }

  return stod(input);
}



/**
  Allows the getDouble method to specify messages without changing the default range.
  @param prompt  The prompt to output to the user.  No default for overload clarity.
  @param error  The response to invalid input.  Default: "Invalid input.  "
  @param minValue  The minimum allowed value.  Default: 2.22507*10^-308
  @param maxValue  The maximum allowed value.  Default: 1.79769*10^+308
  @param boundError  The response to inputs larger than int bounds.  Default: "Out of bounds.  "
  @param genError  The response to errors the code does not handle.  Default: "Unknown error.  " 
  @return  A valid number with a user-inputed value
*/
double getDouble(string prompt, string error = "Invalid input.  ", double minValue = -DBL_MAX, 
  double maxValue = DBL_MAX, string boundError = "Out of bounds.  ", string genError = "Unknown error.  ") {
  string input;
  bool valid = false;

  while (!valid) {
    try {
      start:
      cout << prompt;
      cin >> input;
  
      if (input.find("--") != string::npos) {
        cout << error;
        continue;
      }
      for (int i = 0; i < static_cast<int>(input.length()); ++i) {
        if(!isdigit(input.at(i)) && input.at(i) != '.' && input.at(i) != '-') {
          cout << error;
          goto start;
        }
      }
      if (stod(input) > maxValue || stod(input) < minValue) {
        cout << error;
        goto start;
      }
      else {
        valid = true;
      }
    }
      catch(out_of_range const&) {
        cout << boundError;
      }
      catch(...) {
        cout << genError;
      }
  }

  return stod(input);
}



/**
  Returns a value from an array, if the index is within bounds.
  @param list  The array containing the value
  @param index  The position within the array
  @param manOverride  Permission to get new index if out of bounds.  Default: true
  @return  The array's value at the given index
*/
template <typename dataType> auto getValue(dataType& list, int index, bool manOverride = true) {
  if (index >= 0 && index < sizeof(list)/sizeof(list[0])) {
    return list[index];
  }
  else if(manOverride) {
    cout << "The provided index was out of bounds." << endl;
    index = getInt(0, sizeof(list)/sizeof(list[0]), "Input a new index: ", "Invalid index.  ");
    return getValue(list, index);
  }
  else {
    //Terminates programs lacking error handling
    throw out_of_range("No index " + to_string(index) + " in array.");
  }
}



/**
  Returns and removes the last value from a vector
  @param list  The vector to be truncated
  @return  The value removed from the vector
*/
template <typename dataType> dataType cut(vector<dataType>& list) {
  auto toReturn = list.back();
  list.pop_back();
  return toReturn;
}



/**
  Returns the smallest element of the vector
  @param list  The vector to search
  @param val  Toggles return type between element (true) and index (false).  Default: true
  @return  The smallest element of the vector
*/
template <typename dataType> dataType getMin(vector<dataType>& list, bool returnVal = true) {
  auto smallest = 0;
  for (int i = 0; i < list.size(); ++i) {
    if (list.at(i) < list.at(smallest)) {
      smallest = i;
    }
  }
  
  if (returnVal) {
    return list.at(smallest);
  }
  else return smallest;
}



/**
  Returns the largest element of the vector
  @param list  The vector to search
  @param returnVal  Toggles return type between element (true) and index (false).  Default: true
  @return  The largest element of the vector
*/
template <template <typename...> class Container, typename dataType> dataType getMax(Container<dataType>& list, bool returnVal = true) {
    if (list.size() != 0) {
        auto largest = getValue(list, 0);
        for (int i = 0; i < list.size(); ++i) {
            if (list.at(i) > list.at(largest)) {
                largest = i;
            }
        }

        if (returnVal) {
            return list.at(largest);
        }
        else return largest;   
    }
    else {
        throw out_of_range("No elements in list.");
    }
}



/**
  Returns a vector equivlant of an array
  @param list  The original array
  @return  The new vector
* /
template <typename dataType> vector<typeid(dataType)> convertToVector(dataType& list) {
  vector<dataType> vect(list, list + sizeof(list)/sizeof(list[0]));
  //new vector<dataType> 
  return vect;
}*/



//TODO: Document
bool isNum(string input) {
  bool hasDecimal = false;

  if (input.length() == 0 || input.find("-", 1) != string::npos) {
    return false;
  }

  for (char c : input) {
    if (c == '.') {
      if (hasDecimal) {return false;}
      else {hasDecimal = true;}
    }
    if (!isdigit(c) && c != '-') {
      return false;
    }
  }
  return true;
}

//TODO: Document
string substring(string String, int startingIndex, int endingIndex = -1, bool manOverride = true) {
  if (endingIndex == -1) {endingIndex = String.length();}
  if (startingIndex < endingIndex && startingIndex < String.length() && endingIndex <= String.length() && startingIndex >= 0 && endingIndex > 0) {
    return String.substr(startingIndex, endingIndex-startingIndex);
  }
  else if (manOverride) {
    while (String.length() == 0) {
      cout << "Enter a valid string: ";
      getline(cin, String);
    }
    while (endingIndex > String.length()) {
      endingIndex = getInt(1, String.length(), "Enter an ending index: ");
    }
    while (startingIndex > String.length() -1 || startingIndex >= endingIndex) {
      startingIndex = getInt(0, String.length() -1, "Enter a starting index: ");
    }
    return String.substr(startingIndex, endingIndex-startingIndex);
  }
  else throw invalid_argument("substring(String, startingIndex, endingIndex, manOverride) had one or more invalid parameters.");
}

















#endif