#include "Chess Club Alpha/Main.cpp"
int main() {
  BoardEngine engine = BoardEngine();
  //engine.printBoardText();
  return 0;
}